#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <sstream>
#include <vector>

// General approach of this algorithm:
//	use as much memory as allowed by user for pariwise dist matrix slice
//	for each column:
//		sort members by sort column residue
//		make groups of matching residue members
//		for each group member:
//			increment dist count to non-members

using namespace std;

// ************************************************************************************
// GLOBAL VARIABLES
// ************************************************************************************
char USAGE_STRING[] = "compute_hamming_distance_neighbors [dist_threshold] [memory_limit]";
int num_seqs_total = 0;
int num_seqs_compared = 0;
int num_cols = 0;
double dist_threshold = 0.0;
size_t memory_limit = 0;

// ************************************************************************************
// TYPE DECLARATIONS
// ************************************************************************************

typedef short DistanceType;
typedef vector<int> IntVector;
typedef vector<IntVector> IntVectorVector;
typedef vector<IntVectorVector> IntVectorVectorVector;

// SymmetricArraySlice contains all columns, but a subset of rows from a square matrix
class SymmetricArraySlice {
	DistanceType *data; //TODO: rather than rectangular array, could use two rectangles plus triangle
	DistanceType *bias;
	int row_start;
	int row_count;
	int col_count;
	SymmetricArraySlice& operator=(const SymmetricArraySlice& r);
	SymmetricArraySlice(const SymmetricArraySlice &r);
public:
	SymmetricArraySlice(size_t memory_limit, int column_count);
	~SymmetricArraySlice();
	size_t get_size() const;
	int get_row_count() const {return row_count;}
	int get_col_count() const {return col_count;}
	int get_row_start() const {return row_start;}
	int get_row_end() const {return row_start + row_count - 1;}
	void set_row_start(int r);
	DistanceType& element(int row, int column) const;
	void increase_element(int row, int column) {data[static_cast<size_t>(column) * static_cast<size_t>(row_count) + static_cast<size_t>(row - row_start)]++;}
	void decrease_element(int row, int column) {data[static_cast<size_t>(column) * static_cast<size_t>(row_count) + static_cast<size_t>(row - row_start)]--;}
	void clear();
	void clear_cols(int start_col, int end_col);
	void increase_bias(int col) {bias[col]++;}
	int get_bias(int row) const {return bias[row];}
	int count_neighbors(int row, DistanceType hamming_threshold) const;
};

class FamilyMember {
	string id;
	string status;
	string seq;
	int sas_index;
	int neighbor_count;
public:
	FamilyMember(const string & a_id, const string & a_status,
			const string & a_seq, int a_sas_index) : id(a_id), status(a_status), seq(a_seq), sas_index(a_sas_index) {neighbor_count = 0;}
	const string & get_id() const {return id;}
	const string & get_status() const {return status;}
	const string & get_seq() const {return seq;}
	int get_sas_index() const {return sas_index;}
	int get_neighbor_count() const {return neighbor_count;}
	void set_neighbor_count(int nc) {neighbor_count = nc;}
};

// ************************************************************************************
// SymmetricArraySlice MEMBER FUNCTIONS
// ************************************************************************************

SymmetricArraySlice::SymmetricArraySlice(size_t memory_limit, int column_count) {
	//search for largest row_count which fits in size
	if (column_count < 1) {
		cerr << "error: attempting to create pairwise distance array slice with 0 columns\n";
		exit(1);
	}
	col_count = column_count;
	row_count = 1;
	if (get_size() > memory_limit) {
		cerr << "error: cannot allocate a single row in specified memory limits\n";
		exit(1);
	}
	for(row_count = 2; get_size() < memory_limit;row_count *= 2) {}
	int upper = row_count;
	int lower = row_count / 2;
	while (upper - lower > 1) {
		int middle = (upper + lower) / 2;
		row_count = middle;
		if (get_size() < memory_limit) lower = middle; else upper = middle;
		if (lower >= column_count) break;
	}
	if (lower < column_count) {
		row_count = lower;
	} else {
		row_count = column_count;
	}
	data = static_cast<DistanceType *>(malloc(static_cast<size_t>(row_count) * static_cast<size_t>(col_count) * sizeof(DistanceType)));
	bias = static_cast<DistanceType *>(malloc(static_cast<size_t>(col_count) * sizeof(DistanceType)));
	if (!data || !bias) {
		cerr << "error: memory not available to allocate to specified memory limit\n";
		exit(1);
	}
}

SymmetricArraySlice::~SymmetricArraySlice() {
	free(data);
	free(bias);
}

size_t SymmetricArraySlice::get_size() const {
	return static_cast<size_t>(sizeof(SymmetricArraySlice))
			+ static_cast<size_t>(row_count) * static_cast<size_t>(col_count) * sizeof(DistanceType)
			+ static_cast<size_t>(col_count) * sizeof(DistanceType);
}

DistanceType& SymmetricArraySlice::element(int row, int col) const {
	if (row < row_start || row >= row_start + row_count) {
		cerr << "error: attempt to access cell " << row << ", " << col << " in SymmetricArraySlice (row start=" << row_start << " row_end=" << get_row_end() << ", col_count=" << col_count << ")\n";
		exit(1);
	}
/* no longer used .. but may revert to this later if trying to speed things up
	if (col >= row_start && col <= row_end) {
		if (col > row) {
			int tmp = col;
			col = row;
			row = tmp;
		}
	}
*/
	return data[static_cast<size_t>(col) * static_cast<size_t>(row_count) + static_cast<size_t>(row - row_start)];
}

void SymmetricArraySlice::set_row_start(int r) {
	row_start = r;
}

void SymmetricArraySlice::clear() {
	memset(data,0,static_cast<size_t>(row_count) * static_cast<size_t>(col_count) * static_cast<size_t>(sizeof(DistanceType)));
	for (int col = 0; col < col_count; col++) {
		bias[col] = 0;
	}
}

void SymmetricArraySlice::clear_cols(int start_col, int end_col) {
	DistanceType* start_data_clear = & element(0,start_col);
	memset(start_data_clear,0,static_cast<size_t>(row_count) * static_cast<size_t>(end_col - start_col + 1) * static_cast<size_t>(sizeof(DistanceType)));
	for (int col = start_col; col <= end_col; col++) {
		bias[col] = 0;
	}
}

int SymmetricArraySlice::count_neighbors(int row, DistanceType hamming_threshold) const {
	const DistanceType b = get_bias(row);
	int count = 0;
	for (int col = 0; col < num_seqs_compared; col++) {
		if (b + element(row,col) < hamming_threshold) count++;
	}
	return count;
}

// ************************************************************************************
// GLOBAL FUNCTIONS
// ************************************************************************************
void parse_arguments(int argc, char **argv) {
	if (argc != 3) {
		cerr << USAGE_STRING << endl;
		exit(1);
	}
	istringstream iss1(argv[1]);
	iss1 >> dist_threshold;
	if (iss1.fail() || dist_threshold < 0.0 || dist_threshold > 1.0) {
		cerr << "error: dist_threshold commandline argument (" << argv[1] << " ) is invalid" << endl;
		exit(1);
	}
	istringstream iss2(argv[2]);
	iss2 >> memory_limit;
	if (iss2.fail() || memory_limit < 0) {
		cerr << "error: memory_limit commandline argument (" << argv[2] << " ) is invalid" << endl;
		exit(1);
	}
}

bool get_next_line_from_stdin(ostringstream & line_buf) {
	stringbuf try_buf(ios_base::out);
	cin.get(try_buf); //line
	if (cin.bad()) {
		cerr << "error: stdin corrupted during read" << endl;
		exit(1);
	}
	if (cin.fail()) { //empty line
		cin.clear();
		cin.get(); //delimiter
		if (cin.fail()) return false; //no delimiter
	}
	cin.get(); //delimiter
	if (cin.bad()) {
		cerr << "error: stdin corrupted during read" << endl;
		exit(1);
	}
	if (cin.eof()) {
		return true; //empty last line
	}
	if (cin.fail()) return false; //no delimiter
	line_buf << try_buf.str();
	return true;
}

bool get_next_nonempty_line_from_stdin(ostringstream & line_buf) {
	bool found = false;
	while (found == false) {
		stringbuf try_buf(ios_base::out);
		cin.get(try_buf); //line
		if (cin.bad()) {
			cerr << "error: stdin corrupted during read" << endl;
			exit(1);
		}
		if (cin.fail()) { //empty line
			cin.clear();
			cin.get(); //delimiter
			if (cin.fail()) break; //no delimiter
			continue;
		}
		cin.get(); //delimiter
		if (cin.bad()) {
			cerr << "error: stdin corrupted during read" << endl;
			exit(1);
		}
		if (try_buf.str().length() > 0) {
			line_buf << try_buf.str();
			found = true;
		}
		if (!cin.good()) break;
	}
	return found;
}

void create_family_from_stdin(vector<FamilyMember> & family_member) {
	num_cols = -1;
	num_seqs_compared = 0;
	bool first_line_read = false;
	for (;;) {
		ostringstream id_ss;
		ostringstream status_ss;
		ostringstream seq_ss;
		if (!first_line_read) {
			if (!get_next_nonempty_line_from_stdin(id_ss)) break;
			first_line_read = true;
		} else {
			if (!get_next_line_from_stdin(id_ss)) break;
		}
		if (!get_next_line_from_stdin(status_ss)
				|| !get_next_line_from_stdin(seq_ss)) {
			cerr << "error: incorrect format while reading stdin (end on incomplete record)" << endl;
			exit(1);
		}
		const size_t s_len = seq_ss.str().length();
		if (num_cols == -1) {
			num_cols = s_len;
		} else {
			if (num_cols != s_len) {
				cerr << "error: first sequence has length " << num_cols << " but length " << s_len << " sequence encountered:" << endl;
				cerr << id_ss.str() << endl << status_ss.str() << endl << seq_ss.str() << endl;
				exit(1);
			}
		}
		int sas_index = -1;
		if (status_ss.str() != "suppressed") {
			sas_index = num_seqs_compared;
			num_seqs_compared++;
		}
		family_member.push_back(FamilyMember(id_ss.str(),status_ss.str(),seq_ss.str(),sas_index));
	}
	num_seqs_total = family_member.size();
}

void partition_columns(IntVectorVectorVector & alignment_column_partition, vector<FamilyMember> & family_member) {
	//TODO: idea for speedup --- have two lists in each partition ... members in the slice range and those outside it
	IntVector residue_code(256);
	for (int col = 0; col < num_cols; col++) {
		alignment_column_partition.push_back(IntVectorVector());
		IntVectorVector & col_partition = alignment_column_partition.at(col);
		residue_code.assign(256,256);
		int next_code = 0;
		for (int row = 0; row < num_seqs_total; row++) {
			const int sas_index = family_member[row].get_sas_index();
			if (sas_index < 0) continue; // suppressed sequence .. ignore
			//find code for residue
			unsigned char residue = static_cast<unsigned char>(family_member[row].get_seq()[col]);
			int code = residue_code[residue];
			if (code == 256) {
				code = next_code;
				residue_code[residue] = code;
				col_partition.push_back(IntVector());
				next_code++;
			}
			col_partition[code].push_back(sas_index);
		}
	}
}

void accumulate_distance(SymmetricArraySlice & sas, IntVector & p1, IntVector & p2) {
	const int slice_row_start = sas.get_row_start();
	const int slice_row_end = sas.get_row_end();
	for (IntVector::iterator i1 = p1.begin(); i1 != p1.end(); i1++) {
		if (*i1 < slice_row_start || *i1 > slice_row_end) continue;
		for (IntVector::iterator i2 = p2.begin(); i2 != p2.end(); i2++) sas.increase_element(*i1,*i2);
	}
}

void accumulate_bias(SymmetricArraySlice & sas, IntVector & p) {
	const int slice_row_start = sas.get_row_start();
	const int slice_row_end = sas.get_row_end();
	for (IntVector::iterator i = p.begin(); i != p.end(); i++) {
		if (*i < slice_row_start || *i > slice_row_end) continue;
		sas.increase_bias(*i);
		for (IntVector::iterator j = p.begin(); j != p.end(); j++) sas.decrease_element(*i,*j);
	}
}

void compute_neighbor_counts_in_slice(	IntVector & neighbor_count,
						SymmetricArraySlice & sas,
						IntVectorVectorVector & alignment_column_partition) {
	const int slice_row_start = sas.get_row_start();
	const int slice_row_end = sas.get_row_end();
	sas.clear();
	for (int col = 0; col < num_cols; col++) {
		IntVectorVector & col_partition = alignment_column_partition.at(col);
		const int col_partition_size = col_partition.size();
		for (int i = 0; i < col_partition_size; i++) {
			IntVector& cp_i = col_partition[i];
			if (cp_i.size() <= num_seqs_compared / 2) {
				//smallish part
				accumulate_bias(sas, cp_i);
			} else {
				//bigish part
				for (int j = 0; j < col_partition_size; j++) {
					if (i == j) continue; // don't accumulate distance when elements are in same partition
					accumulate_distance(sas, cp_i, col_partition[j]);
				}
			}
		}
	}
	double distance_threshold = dist_threshold * num_cols;
	DistanceType hamming_threshold = static_cast<DistanceType>(distance_threshold);
	if (floor(distance_threshold) != distance_threshold) {
		hamming_threshold++;
	}
	for (int row = slice_row_start; row <= slice_row_end && row < num_seqs_compared; row++) {
		neighbor_count[row] = sas.count_neighbors(row,hamming_threshold);
	}

/* no longer used .. but may revert to this later if trying to speed things up
	//cols in the last slice (transpose from before)
	if (last_slice_row_start != INT_MAX) {
		int source_row = slice_row_start - 1;
		for (int row = slice_row_start; row <= slice_row_end; row++) {
			int source_col = slice_row;
			for (int col = slice_row_start - 1; col >= first_copy_column; col--) {
				sas.element(row,col) = sas.element(source_row,source_col);
				source_col++;
			}
			source_row--;
		}
	}
*/
}

void compute_neighbor_counts(vector<FamilyMember> & family_member) {
	IntVectorVectorVector alignment_column_partition;
	partition_columns(alignment_column_partition, family_member);
	SymmetricArraySlice sas(memory_limit, num_seqs_compared);
	sas.set_row_start(0);
	sas.clear();
	IntVector sas_indexed_neighbor_count;
	sas_indexed_neighbor_count.resize(num_seqs_compared);
	for (int slice_row_start = 0; slice_row_start < num_seqs_compared; slice_row_start += sas.get_row_count()) {
		sas.set_row_start(slice_row_start);
		compute_neighbor_counts_in_slice(sas_indexed_neighbor_count, sas, alignment_column_partition);
	}
	for (int row = 0; row < num_seqs_total; row++) {
		const int family_member_sas_index = family_member[row].get_sas_index();
		if (family_member_sas_index != -1) {
			family_member[row].set_neighbor_count(sas_indexed_neighbor_count[family_member_sas_index]);
		}
	}
}

void output_neighbor_count_table(vector<FamilyMember> & family_member) {
	for (int i = 0; i < num_seqs_total; i++) {
		cout << family_member[i].get_id() << "\t";
		cout << family_member[i].get_status() << "\t";
		int neighbor_count = family_member[i].get_neighbor_count();
		if (neighbor_count == 0) {
			cout << 0 << "\t" << 0 << endl;
		} else {
			cout << neighbor_count << "\t" << (1.0 / neighbor_count) << endl;
		}
	}
}

int main(int argc, char **argv) {
	parse_arguments(argc, argv);
	vector<FamilyMember> family_member;
	create_family_from_stdin(family_member); //sets num_seqs_total and num_cols
	if (family_member.size()== 0) {
		cerr << "error: failure during read of alignment (stdin)" << endl;
		exit(1);
	}
	compute_neighbor_counts(family_member);
	output_neighbor_count_table(family_member);
	return 0;
}
