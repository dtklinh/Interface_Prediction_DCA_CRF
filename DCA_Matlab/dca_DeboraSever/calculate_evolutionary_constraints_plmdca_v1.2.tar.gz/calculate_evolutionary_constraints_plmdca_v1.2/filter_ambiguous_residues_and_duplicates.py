#!/usr/bin/python

import sys
import os
from optparse import OptionParser
from string import maketrans

parser = OptionParser()
#sequence  of interest is now always on the first line of the alignment
parser.add_option('-m', '--method_for_nonstandard', dest='method_for_nonstandard',
        help='method for dealing with nonstandard and ambiguous residue codes (default:suppress_member)', metavar='suppress_member|substitute_gap')
parser.add_option('-u', '--unique_sequence_policy', dest='unique_sequence_policy',
        help='policy for filtering duplicate (condensed) sequences (default:no_filter)', metavar='no_filter|filter_perfect_match|filter_subsequence')
parser.add_option('-g', '--gap_percentage_limit', dest='member_gap_percentage_limit',
        help='members with more than this percentage of gaps are filtered (default:100)')
(options, args) = parser.parse_args()

if (options.method_for_nonstandard == None):
    options.method_for_nonstandard = 'suppress_member'
if (options.unique_sequence_policy == None):
    options.unique_sequence_policy = 'no_filter'
if (options.member_gap_percentage_limit == None):
    options.member_gap_percentage_limit = '100'
if (options.method_for_nonstandard != 'suppress_member' and options.method_for_nonstandard != 'substitute_gap'):
    sys.stderr.write('error: unrecognized option for --method_for_nonstandard (' + options.method_for_nonstandard + ')\nusage: prepare_alignment_for_distance_calculation.py [-m suppress_member|substitute_gap] [-u no_filter|filter_perfect_match|filter_subsequence] [inputfile]\n')
    exit(1)
if (options.unique_sequence_policy != 'no_filter' and options.unique_sequence_policy != 'filter_perfect_match' and options.unique_sequence_policy != 'filter_subsequence'):
    sys.stderr.write('error: unrecognized option for --unique_sequence_policy(' + options.method_for_nonstandard + ')\nusage: prepare_alignment_for_distance_calculation.py [-m suppress_member|substitute_gap] [-u no_filter|filter_perfect_match|filter_subsequence] [inputfile]\n')
    exit(1)
member_gap_pct_limit = int(float(options.member_gap_percentage_limit))

#read fasta file
fasta_identifier = []
fasta_sequence = []
inputstream = sys.stdin
if (len(args) > 0):
    f = open(args[0],'r')
    inputstream = f
try:
    rawfilelines = inputstream.read()
finally:
    f.close()

rawfilelines = rawfilelines.replace('\r','\n')
sequencepairs = rawfilelines.split('\n>')
firstsequenceflag = True
for sequencepair in sequencepairs:
    if (firstsequenceflag):
        firstsequenceflag = False
        #clean up first record
        gt_pos = sequencepair.find('>')
        if (gt_pos >= 0 and len(sequencepair) > gt_pos):
            sequencepair = sequencepair[gt_pos + 1:]
            firstsecond = sequencepair.split('\n',1)
            fasta_identifier.append(firstsecond[0])
            if (len(firstsecond) < 2):
                fasta_sequence.append('')
            else:
                fasta_sequence.append(firstsecond[1].translate(maketrans('',''),' \t\n\f\v\b\a\x1b'))
    else:
        firstsecond = sequencepair.split('\n',1)
        fasta_identifier.append(firstsecond[0])
        if (len(firstsecond) < 2):
            fasta_sequence.append('')
        else:
            fasta_sequence.append(firstsecond[1].translate(maketrans('',''),' \t\n\f\v\b\a\x1b'))

#test that at least 1 sequence was read
if (len(fasta_sequence) == 0):
    sys.stderr.write('error: fasta file contained no valid sequences\n')
    exit(1)

#test that all sequences have the same length
fasta_alignment_width = len(fasta_sequence[0])
for seq_index in range(1,len(fasta_sequence)):
    if (len(fasta_sequence[seq_index]) != fasta_alignment_width):
        sys.stderr.write('error: the width of the first sequence was ' + str(fasta_alignment_width) + ', which did not match sequence #' + str(seq_index + 1) + ' which had width ' + str(len(fasta_sequence[seq_index])) + '\n' + fasta_sequence[0] + '\n' + fasta_sequence[seq_index] + '\n')
        exit(1)

sequence_of_interest_index = 0

#find the capital letter positions in the sequence of interest
sequence_of_interest = fasta_sequence[sequence_of_interest_index]
if (sequence_of_interest.find('>') != -1):
    sys.stdout.write('error: sequence of interest contains illegal character ">" : ' + sequence_of_interest + '\n')
    exit(1)
masked_ambiguous_sequence = sequence_of_interest.translate(maketrans('BZJXUO','>>>>>>'))
if (masked_ambiguous_sequence.find('>') != -1):
    sys.stdout.write('error: sequence of interest contains one or more ambiguous/nonstandard residues (B,Z,J,X,U,O) : ' + sequence_of_interest + '\n')
    exit(1)
masked_capital_sequence = sequence_of_interest.translate(maketrans('ARNDCEQGHILKMFPSTWYV','>>>>>>>>>>>>>>>>>>>>'))
capital_letter_column_flag = []
for residue in masked_capital_sequence:
    capital_letter_column_flag.append(residue == '>')
sequence_of_interest_ungapped_length = len(sequence_of_interest.translate(maketrans('',''),'.-'))

ambiguous_phase_fasta_identifier = []
ambiguous_phase_fasta_sequence = []
#apply ambiguous residue policy on capital columns
ambiguous_residues = set(['B','Z','J','X','U','O'])
if options.method_for_nonstandard == 'suppress_member':
    for seq_pos in range(0,len(fasta_sequence)):
        start_seq = fasta_sequence[seq_pos]
        if (len(start_seq) == len(start_seq.translate(maketrans('',''),'BZJXUO'))):
            ambiguous_phase_fasta_identifier.append(fasta_identifier[seq_pos])
            ambiguous_phase_fasta_sequence.append(start_seq)
else:
    for seq_pos in range(0,len(fasta_sequence)):
        ambiguous_phase_fasta_identifier.append(fasta_identifier[seq_pos])
        ambiguous_phase_fasta_sequence.append(fasta_sequence[seq_pos].translate(maketrans('BZJXUO','------'))) #substitute gaps

gap_phase_fasta_identifier = []
gap_phase_fasta_sequence = []
#apply gap content filter
if (member_gap_pct_limit < 100):
    for seq_pos in range(0,len(ambiguous_phase_fasta_sequence)):
        ungapped_seq_len = len(ambiguous_phase_fasta_sequence[seq_pos].translate(maketrans('',''),'.-'))
        gap_pct = (1.0 - (float(ungapped_seq_len) / float(sequence_of_interest_ungapped_length))) * 100.0
        if (gap_pct <= member_gap_pct_limit):
            gap_phase_fasta_identifier.append(ambiguous_phase_fasta_identifier[seq_pos])
            gap_phase_fasta_sequence.append(ambiguous_phase_fasta_sequence[seq_pos])
else:
    gap_phase_fasta_identifier = ambiguous_phase_fasta_identifier
    gap_phase_fasta_sequence = ambiguous_phase_fasta_sequence

gap_phase_fasta_sequence_compressed = []
unique_phase_fasta_identifier = []
unique_phase_fasta_sequence = []
unique_sequence = set() # using a set is what gives a non-duplicate sequence group
if (options.unique_sequence_policy != 'no_filter'):
    #suppress exact duplicates (considering only capital columns)
    for seq in gap_phase_fasta_sequence:
        compressed_seq = seq.translate(maketrans('',''),'abcdefghijklmnopqrstuvwxyz.')
        gap_phase_fasta_sequence_compressed.append(compressed_seq)
        unique_sequence.add(compressed_seq)
    for seq_pos in range(0,len(gap_phase_fasta_sequence)):
        if (gap_phase_fasta_sequence_compressed[seq_pos] in unique_sequence):
            unique_phase_fasta_identifier.append(gap_phase_fasta_identifier[seq_pos])
            unique_phase_fasta_sequence.append(gap_phase_fasta_sequence[seq_pos])
            unique_sequence.remove(gap_phase_fasta_sequence_compressed[seq_pos])

    if (options.unique_sequence_policy == 'filter_subsequence'):
        #TODO:suppress subsequence duplicates
             #make set of candidates, record extent (first non-gap, last non-gap)
            #concepts:
            # - can use "contained-in" relationships to reduce pairwise comparisons
            # - can simply use length to reduce pairwise comparisons (as proxy for contained-in)
            # - can find columns with most even distribution of amino acids and use one or more (or recursive) to sort group into partition (differing amino acid -> cannot be subsequence)
            # - important to never filter the sequence of interest (special treatment)
        sys.stderr.write('error: filter_subsequene option not yet implemented')
        exit(1)
else:
    unique_phase_fasta_identifier = gap_phase_fasta_identifier
    unique_phase_fasta_sequence = gap_phase_fasta_sequence

for pos in range(0,len(unique_phase_fasta_identifier)):
    sys.stdout.write('>' + unique_phase_fasta_identifier[pos] + "\n")
    sys.stdout.write(unique_phase_fasta_sequence[pos] + "\n")
#    sys.stdout.write(status_code[pos] + "\n")
#    sys.stdout.write(condensed_sequence[pos] + "\n")

#the following is the previous (slow) approach for doign theta calculation in this script
#THETA_THRESHOLD = len(condensed_sequence[0]) * float(options.theta)
#
#def number_within_theta(i):
#    count = 0
#    for j in range(0,len(condensed_sequence)):
#        if (within_theta(i,j)):
#            count = count + 1
#    return count
#
#def within_theta(i,j):
#    seq_i = condensed_sequence[i]
#    seq_j = condensed_sequence[j]
#    diffcount = 0
#    for scanpos in range(0,len(seq_i)):
#        if (seq_i[scanpos] != seq_j[scanpos]):
#            diffcount = diffcount + 1
#            if (diffcount >= THETA_THRESHOLD):
#                return False
#    return True
#
#for i in range(0,len(condensed_sequence)):
#    sys.stdout.write(str(i) + '\t' + str(number_within_theta(i)) + '\n')
