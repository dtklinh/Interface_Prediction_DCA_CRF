% Copyright 2012 - by Magnus Ekeberg (magnus.ekeberg@gmail.com)
% All rights reserved
%
% Permission is granted for anyone to copy, use, or modify this
% software for any uncommercial purposes, provided this copyright
% notice is retained, and note is made of any changes that have
% been made. This software is distributed without any warranty,
% express or implied. In no event shall the author or contributors be
% liable for any damage arising out of the use of this software.
%
% The publication of research using this software, modified or not, must include an
% appropriate citation to:
%     M. Ekeberg, C. Lövkvist, Y. Lan, M. Weigt, E. Aurell, Improved contact
%     prediction in proteins: Using pseudolikelihoods to infer Potts models, arXiv:1211.1281
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Notes of Changes made for EVfold adaptation:
%
% - Inserted letter2number_map, created by create_letter2number_map(), accomplishes
%     encoding and detection of ambiguous / non-conserved residue codes
% - Added find_seq_of_interest() function to locate reference sequence by seq_id
% - Added scan_sequence_of_interest_for_focus_columns() to identify match columns (upper case)
%     and restrict encoding to only those columns
% - Added scan_sequence_of_interest_for_focus_columns() helper function
% - Deleted provided function [fi, fij] = calculate_frequencies(Y, Yr, B, B_eff, N, q)
% - Standardized indentation style and other syntax conventions
% - Made some variable names more specific (e.g. fastafile -> msa_fasta_filename)
% - Dropped reweighting code; replace with reading of weights from external file
%     (msa_weight_table_filename --> family_neighbor_count)
% - Dropped some diagnostic stdout print statements
% - Dropped profiling marks
% - Added environment variable METHOD_TO_RESOLVE_AMBIGUOUS_RESIDUES ... which
%     either suppresses sequence which have ambiguous residues or subsitutes gaps
% - "focus_alignment" now is the encoded columns and rows (omitting suppressed
%     sequences and lowercase columns) mappings in focuscolumnlist, and
%     focus_to_uniprot_offset_map
% - Indexing (offsets) of seq_of_interest is determined using PFAM-like slash
%     notation (>PROTEIN_ID/###-###)
% - Added special identifier 'use_first_member_as_sequence_of_interest' to
%     allow simple identification, and also avoid redundancy ambiguity
% - All function arguments are read as strings now, and converted to numbers if
%     needed (to allow better command-line use with MCR compiled mode)
% - Removal of duplicate sequences from alignment moved to external tool
% - Unused components from minFunc dropped from code base
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function plmDCA_symmetric_evfold(msa_fasta_filename, msa_weight_table_filename, target_seq_id, output_filename, lambda_h_string, lambda_J_string, nr_of_cores_string)
    options.method = 'cg';    %Minimization scheme. Default: 'lbfgs', 'cg' for conjugate gradient (use 'cg' if out of RAM)
    options.optTol = 1e-5;    %default: 1e-5
    options.progTol = 1e-7;   %default: 1e-9
    lambda_h = str2num(lambda_h_string);
    lambda_J = str2num(lambda_J_string);
    nr_of_cores = str2num(nr_of_cores_string);
    if ~isdeployed
        addpath(genpath(pwd))
    end
    family_neighbor_count = read_weight_table(msa_weight_table_filename);
    %Read inputfile (removing inserts), remove duplicate sequences, and calculate weights (Yr) and B_eff
    [Y, target_seq, focus_to_uniprot_offset_map] = return_alignment(msa_fasta_filename, target_seq_id, family_neighbor_count);
    q = max(max(Y));
    [B, N] = size(Y);
    Y = int32(Y);
    Yr = 1 ./ family_neighbor_count;
    B_eff = sum(Yr);
    %Set up and run optimizer
    field_lambda = lambda_h * B_eff;
    coupling_lambda = lambda_J * B_eff;
    edges = [];
    for i = 1:(N - 1)
        for j = i + 1:N
            edges = [edges; [i, j]];
        end
    end
    Y = int32(Y);
    q = int32(q);
    edges = int32(edges);
    funObj = @(w)pseudo_likelihood_symmetric(w, Y, Yr, q, edges, field_lambda, coupling_lambda);
    w0 = zeros(q * N + q ^ 2 * N * (N - 1) / 2, 1);
    if nr_of_cores>1
        matlabpool('open', nr_of_cores)
        w = minFunc(funObj, w0, options);
        matlabpool('close')
    else
        w = minFunc(funObj, w0, options);
    end
    Jtemp = reshape(w((q * N + 1):end), q, q, N * (N - 1) / 2);
    %Change parameter gauge for J
    J = zeros(q, q, N * (N - 1) / 2);
    for l = 1:(N * (N - 1) / 2)
        J(:, :, l) = Jtemp(:, :, l) - repmat(mean(Jtemp(:, :, l)), q, 1) - repmat(mean(Jtemp(:, :, l), 2), 1, q) + mean(mean(Jtemp(:, :, l)));
    end
    %Calculate frob. norms FN_ij
    NORMS = zeros(N, N);
    l = 1;
    for i = 1:(N - 1)
        for j = (i + 1):N
            NORMS(i, j) = norm(J(1:end, 1:end, l), 'fro');
            NORMS(j, i) = NORMS(i, j);
            l = l + 1;
        end
    end
    %Calculate final scores, CN_ij = FN_ij-(FN_i-)(FN_-j)/(FN_--), where '-' denotes average
    norm_means = mean(NORMS) * N / (N - 1);
    norm_means_all = mean(mean(NORMS)) * N/(N - 1);
    CORRNORMS = NORMS - norm_means' * norm_means / norm_means_all;
    number2letter_map = create_number2letter_map();
    output = [];
    fp = fopen(output_filename, 'w');
    for i = 1:(N - 1)
        for j = (i + 1):N
            fprintf(fp, '%d %s %d %s %g %g\n', focus_to_uniprot_offset_map(i), number2letter_map(target_seq(i)), focus_to_uniprot_offset_map(j), number2letter_map(target_seq(j)), 0.0, CORRNORMS(i, j));
        end
    end
    fclose(fp);
    %exit
end

function family_neighbor_count = read_weight_table(msa_weight_table_filename)
    fp = fopen(msa_weight_table_filename, 'r');
    raw_table_input = textscan(fp,'%s%s%f%f');
    fclose(fp);
    family_neighbor_count = raw_table_input{3}';
end

function [encoded_focus_alignment, encoded_seq_of_interest, focus_to_uniprot_offset_map] = return_alignment(msa_fasta_filename, seqid_of_interest, family_neighbor_count)
    METHOD_TO_RESOLVE_AMBIGUOUS_RESIDUES = getenv('EC_METHOD_TO_RESOLVE_AMBIGUOUS_RESIDUES'); % must be either suppress_member or substitute_gaps
    if (size(METHOD_TO_RESOLVE_AMBIGUOUS_RESIDUES, 2) == 0)
            METHOD_TO_RESOLVE_AMBIGUOUS_RESIDUES = 'suppress_member';
    end
    full_alignment = fastaread(msa_fasta_filename);
    alignment_height = size(full_alignment, 1);
    letter2number_map = create_letter2number_map();
    [full_index_of_interest, range_of_interest_start, range_of_interest_end] = find_seq_of_interest(full_alignment, seqid_of_interest);
    encoded_focus_alignment = [];
    focus_neighbor_count = [];
    [focuscolumnlist, focus_to_uniprot_offset_map] = scan_sequence_of_interest_for_focus_columns(full_alignment(full_index_of_interest).Sequence, range_of_interest_start, letter2number_map);
    for full_alignment_index = 1:alignment_height
        focus_alignment_row = full_alignment(full_alignment_index).Sequence(focuscolumnlist);
        encoded_focus_alignment_row = letter2number_map(focus_alignment_row);
        if (size(find(encoded_focus_alignment_row == 0), 2) > 0)
            error(['Error: sequence in alignment has illegal characters: ' full_alignment(full_alignment_index).Sequence]);
        end
        if (size(find(encoded_focus_alignment_row <= -2), 2) > 0)
            error(['Error: sequence in alignment has dot or lowercase in conserved position: ' full_alignment(full_alignment_index).Sequence]);
        end
        if (size(find(encoded_focus_alignment_row == -1), 2) > 0)
            if (strcmp(METHOD_TO_RESOLVE_AMBIGUOUS_RESIDUES,'substitute_gap') == 1)
                encoded_focus_alignment_row(find(encoded_focus_alignment_row == -1)) = 1;
            else
                if (strcmp(METHOD_TO_RESOLVE_AMBIGUOUS_RESIDUES,'suppress_member') == 1)
                    continue %skip sequences with ambiguous residues
                else
                    error('Internal Error');
                end
            end
        end
        encoded_focus_alignment(size(encoded_focus_alignment, 1) + 1, :) = encoded_focus_alignment_row;
        if (full_alignment_index == full_index_of_interest)
            encoded_seq_of_interest = encoded_focus_alignment_row;
        end
        focus_neighbor_count(size(focus_neighbor_count, 2) + 1) = family_neighbor_count(full_alignment_index);
    end
end

function [index_of_interest, range_start, range_end] = find_seq_of_interest(full_alignment, seqid_of_interest)
    index_of_interest = -1;
    use_first_sequence = (strcmp(seqid_of_interest,'use_first_member_as_sequence_of_interest') == 1);
    for scan_index = 1:size(full_alignment, 1)
        [seqid, range_start, range_end] = split_uniprot_id(full_alignment(scan_index).Header);
        if (strcmp(seqid, seqid_of_interest) == 1 || use_first_sequence)
            index_of_interest = scan_index;
            break
        end
    end
    if (index_of_interest == -1)
        error(['Error: could not find sequence of interest (' seqid_of_interest ') in multiple sequence alignment']);
    end
end

function [seqid, range_start, range_end] = split_uniprot_id(pfam_uniprot_range_line)
    slashposition = findstr('/', pfam_uniprot_range_line);
    if (size(slashposition, 2) ~= 1 || slashposition == 1 || slashposition == size(pfam_uniprot_range_line, 2))
        error(['Error: could not parse (slash error) uniprot range line in pfam alignment : ' pfam_uniprot_range_line]);
    end
    seqid = pfam_uniprot_range_line(1:slashposition - 1);
    rangestring = pfam_uniprot_range_line(slashposition + 1:size(pfam_uniprot_range_line, 2));
    hyphenposition = findstr('-', rangestring);
    if (size(hyphenposition, 2) ~= 1 || hyphenposition == 1 || hyphenposition == size(rangestring, 2))
        error(['Error: could not parse (hyphen error) uniprot range line in pfam alignment : ' pfam_uniprot_range_line]);
    end
    range_start = str2num(rangestring(1:hyphenposition - 1));
    range_end = str2num(rangestring(hyphenposition + 1 : size(rangestring, 2)));
    if (isempty(range_start) || isempty(range_end))
        error(['Error: could not parse (range start/end) uniprot range line in pfam alignment : ' pfam_uniprot_range_line]);
    end
end

function [focuscolumnlist, uniprotoffsetlist] = scan_sequence_of_interest_for_focus_columns(sequence_of_interest, range_of_interest_start, letter2number_map)
    focuscolumnlist = [];
    uniprotoffsetlist = [];
    next_uniprotoffset = range_of_interest_start;
    for pos = 1:size(sequence_of_interest, 2)
        residuecode = letter2number_map(sequence_of_interest(pos));
        if (residuecode == 0)
            error(['Error: sequence of interest contains undefined residues:' sequence_of_interest]);
        end
        if (residuecode == -1)
            error(['Error: sequence of interest contains ambiguous residues:' sequence_of_interest]);
        end
        if (residuecode > 1)
            focuscolumnlist = [focuscolumnlist pos];
            uniprotoffsetlist = [uniprotoffsetlist next_uniprotoffset];
        end
        if (residuecode == -2 || residuecode > 1)
            next_uniprotoffset = next_uniprotoffset + 1;
        end
    end
end

function letter2number_map = create_letter2number_map()
    letter2number_map(256) = 0; %initiallize all bytes to 0
    letter2number_map('-') = 1;
    letter2number_map('A') = 2;
    letter2number_map('C') = 3;
    letter2number_map('D') = 4;
    letter2number_map('E') = 5;
    letter2number_map('F') = 6;
    letter2number_map('G') = 7;
    letter2number_map('H') = 8;
    letter2number_map('I') = 9;
    letter2number_map('K') = 10;
    letter2number_map('L') = 11;
    letter2number_map('M') = 12;
    letter2number_map('N') = 13;
    letter2number_map('P') = 14;
    letter2number_map('Q') = 15;
    letter2number_map('R') = 16;
    letter2number_map('S') = 17;
    letter2number_map('T') = 18;
    letter2number_map('V') = 19;
    letter2number_map('W') = 20;
    letter2number_map('Y') = 21;
    letter2number_map('B') = -1; %ambiguous : skip sequences containing these
    letter2number_map('Z') = -1; %ambiguous : skip sequences containing these
    letter2number_map('J') = -1; %ambiguous : skip sequences containing these
    letter2number_map('X') = -1; %ambiguous : skip sequences containing these
    letter2number_map('U') = -1; %non-standard : skip sequences containing these
    letter2number_map('O') = -1; %non-standard : skip sequences containing these
    letter2number_map('a') = -2; %non-conserved: skip in seq of interest
    letter2number_map('c') = -2; %non-conserved: skip in seq of interest
    letter2number_map('d') = -2; %non-conserved: skip in seq of interest
    letter2number_map('e') = -2; %non-conserved: skip in seq of interest
    letter2number_map('f') = -2; %non-conserved: skip in seq of interest
    letter2number_map('g') = -2; %non-conserved: skip in seq of interest
    letter2number_map('h') = -2; %non-conserved: skip in seq of interest
    letter2number_map('i') = -2; %non-conserved: skip in seq of interest
    letter2number_map('k') = -2; %non-conserved: skip in seq of interest
    letter2number_map('l') = -2; %non-conserved: skip in seq of interest
    letter2number_map('m') = -2; %non-conserved: skip in seq of interest
    letter2number_map('n') = -2; %non-conserved: skip in seq of interest
    letter2number_map('p') = -2; %non-conserved: skip in seq of interest
    letter2number_map('q') = -2; %non-conserved: skip in seq of interest
    letter2number_map('r') = -2; %non-conserved: skip in seq of interest
    letter2number_map('s') = -2; %non-conserved: skip in seq of interest
    letter2number_map('t') = -2; %non-conserved: skip in seq of interest
    letter2number_map('v') = -2; %non-conserved: skip in seq of interest
    letter2number_map('w') = -2; %non-conserved: skip in seq of interest
    letter2number_map('y') = -2; %non-conserved: skip in seq of interest
    letter2number_map('b') = -2; %non-conserved: skip in seq of interest
    letter2number_map('z') = -2; %non-conserved: skip in seq of interest
    letter2number_map('j') = -2; %non-conserved: skip in seq of interest
    letter2number_map('x') = -2; %non-conserved: skip in seq of interest
    letter2number_map('u') = -2; %non-conserved: skip in seq of interest
    letter2number_map('o') = -2; %non-conserved: skip in seq of interest
    letter2number_map('.') = -3; %non-conserved: skip in seq of interest, do not advance position
end

function number2letter_map = create_number2letter_map()
    number2letter_map(1) = '-';
    number2letter_map(2) = 'A';
    number2letter_map(3) = 'C';
    number2letter_map(4) = 'D';
    number2letter_map(5) = 'E';
    number2letter_map(6) = 'F';
    number2letter_map(7) = 'G';
    number2letter_map(8) = 'H';
    number2letter_map(9) = 'I';
    number2letter_map(10) = 'K';
    number2letter_map(11) = 'L';
    number2letter_map(12) = 'M';
    number2letter_map(13) = 'N';
    number2letter_map(14) = 'P';
    number2letter_map(15) = 'Q';
    number2letter_map(16) = 'R';
    number2letter_map(17) = 'S';
    number2letter_map(18) = 'T';
    number2letter_map(19) = 'V';
    number2letter_map(20) = 'W';
    number2letter_map(21) = 'Y';
end
